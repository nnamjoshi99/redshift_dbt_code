with weekly_aggregates as (
    select
        market_id,
        product_id,
        date_trunc('week', price_date) as price_week,
        avg(price_amount) as avg_weekly_price,
        min(price_amount) as min_weekly_price,
        max(price_amount) as max_weekly_price,
        count(*) as price_count
    from {{ ref('stg_market_price') }}
    group by 1, 2, 3
)

select
    w.*,
    m.market_name,
    m.market_region,
    m.market_type
from weekly_aggregates w
left join {{ ref('stg_market_master') }} m
    on w.market_id = m.market_id
where m.is_active = true
