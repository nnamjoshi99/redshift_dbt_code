with weekly_metrics as (
    select
        market_id,
        market_name,
        market_region,
        market_type,
        product_id,
        price_week,
        avg_weekly_price,
        min_weekly_price,
        max_weekly_price,
        price_count,
        (max_weekly_price - min_weekly_price) as price_range,
        case 
            when lag(avg_weekly_price) over(partition by market_id, product_id order by price_week) is not null
            then (avg_weekly_price - lag(avg_weekly_price) over(partition by market_id, product_id order by price_week)) 
            else 0 
        end as price_change_from_previous_week,
        row_number() over(partition by market_id, product_id order by price_week desc) as recency_rank
    from {{ ref('int_weekly_prices') }}
)

select
    market_id,
    market_name,
    market_region,
    market_type,
    product_id,
    price_week,
    avg_weekly_price,
    min_weekly_price,
    max_weekly_price,
    price_count,
    price_range,
    price_change_from_previous_week,
    current_timestamp as dbt_updated_at
from weekly_metrics
