with source as (
    select * from {{ source('raw', 'market_price') }}
),

renamed as (
    select
        market_id,
        product_id,
        price_date,
        price_amount,
        created_at,
        updated_at
    from source
)

select * from renamed
