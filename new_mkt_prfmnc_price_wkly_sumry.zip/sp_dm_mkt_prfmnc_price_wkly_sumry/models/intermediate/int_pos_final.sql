with pos_sales as (
    select * from {{ ref('int_pos_sales') }}
),

customer_master as (
    select distinct
        sold_to_nbr,
        sold_to_nm,
        plan_to_nbr,
        plan_to_nm,
        tdlinx_nbr,
        hier_d_sales_mgmt_a_nm
    from {{ source('cust_mstr', 'cust_sold_to_pivot') }}
    where trim(tdlinx_nbr) != ''
    and upper(hier_d_sales_mgmt_a_nm) not in ('CANADA L3', 'REMARKETING', 'PUREPLAY E-COMMERCE', 'SPECIALTY')
),

material_master as (
    select distinct
        gtin,
        upper(catg_nm) as catg_nm,
        upper(dp_bu_cd) as dp_bu_cd,
        upper(comrcl_catg_cd) as comrcl_catg_cd
    from {{ source('matrl_mstr', 'gtin') }}
    where upper(comrcl_catg_cd) != 'WIP'
),

pos_with_customer as (
    select 
        pos.*,
        case
            when retlr_nm not in ('C&S', 'DOLLAR GENERAL', 'SAMS CLUB') then cust.sold_to_nm
            else null
        end as sold_to_nm,
        case
            when retlr_nm not in ('C&S', 'DOLLAR GENERAL', 'SAMS CLUB') then cust.plan_to_nbr
            else coalesce(cust_pln_to.plan_to_nbr, '')
        end as plan_to_nbr,
        case
            when retlr_nm not in ('C&S', 'DOLLAR GENERAL', 'SAMS CLUB') then cust.plan_to_nm
            else retlr_nm
        end as plan_to_nm
    from pos_sales pos
    left join customer_master cust
        on pos.sold_to_nbr = cust.sold_to_nbr
    left join (
        select distinct plan_to_nbr, plan_to_nm 
        from customer_master
        where retlr_nm in ('C&S', 'DOLLAR GENERAL', 'SAMS CLUB')
    ) cust_pln_to
        on pos.retlr_nm = cust_pln_to.plan_to_nm
)

select 
    pos.*,
    mat.catg_nm,
    mat.dp_bu_cd,
    mat.comrcl_catg_cd,
    fcal.fisc_wk_end_dt
from pos_with_customer pos
left join material_master mat
    on pos.gtin = mat.gtin
left join {{ source('fin_acctg_ops', 'ref_fisc_cal_wk') }} fcal
    on (pos.fisc_yr || pos.fisc_wk) = fcal.fisc_yr_wk
