with sales_tracker as (
    select * from {{ ref('stg_sales_tracker') }}
),

customer_master as (
    select distinct 
        plan_to_nbr,
        plan_to_nm
    from {{ source('cust_mstr', 'cust_sold_to_pivot') }}
    where trim(tdlinx_nbr) != ''
    and upper(hier_d_sales_mgmt_a_nm) not in ('CANADA L3', 'REMARKETING', 'PUREPLAY E-COMMERCE', 'SPECIALTY')
),

aggregated as (
    select
        plan_to_nbr,
        fisc_yr,
        fisc_qtr,
        fisc_pd,
        fisc_yr_qtr,
        fisc_yr_pd,
        catg_nm,
        dp_bu_cd,
        val_curr_cd,
        comrcl_catg_cd,
        ytd_ytg_cd,
        src_nm,
        sum(case when meas_nm = 'NET SALES' then actl_meas_val else 0.0 end) as actl_nsv,
        sum(case when meas_nm = 'NET SALES' then actl_yr_ago_meas_val else 0.0 end) as yr_ago_actl_nsv,
        sum(case when meas_nm = 'GROSS SALES' then actl_meas_val else 0.0 end) as actl_gsv,
        sum(case when meas_nm = 'GROSS SALES' then actl_yr_ago_meas_val else 0.0 end) as yr_ago_actl_gsv,
        sum(case when meas_nm = 'KILOS' then actl_meas_val else 0.0 end) as actl_net_kg_val,
        sum(case when meas_nm = 'KILOS' then actl_yr_ago_meas_val else 0.0 end) as yr_ago_actl_net_kg_val,
        sum(case when meas_nm = 'GROSS PROFIT 2' then actl_meas_val else 0.0 end) as actl_gross_prft_val,
        sum(case when meas_nm = 'GROSS PROFIT 2' then actl_yr_ago_meas_val else 0.0 end) as yr_ago_actl_gross_prft_val,
        sum(case when meas_nm = 'TRADE' then actl_meas_val else 0.0 end) as actl_trade_val,
        sum(case when meas_nm = 'TRADE' then actl_yr_ago_meas_val else 0.0 end) as yr_ago_trade_val
    from sales_tracker
    group by 1,2,3,4,5,6,7,8,9,10,11,12
)

select
    a.*,
    case when b.plan_to_nm like 'C&S%' then 'C&S' else upper(b.plan_to_nm) end as plan_to_nm
from aggregated a
left join customer_master b
    on a.plan_to_nbr = b.plan_to_nbr
