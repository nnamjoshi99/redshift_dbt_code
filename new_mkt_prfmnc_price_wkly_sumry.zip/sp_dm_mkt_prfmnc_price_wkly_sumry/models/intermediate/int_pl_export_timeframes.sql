with pl_export as (
    select * from {{ ref('int_pl_export') }}
),

qtd_timeframe as (
    select 
        plan_to_nm,
        plan_to_nbr,
        'QTD' as tmfrm_cd,
        catg_nm,
        dp_bu_cd,
        comrcl_catg_cd,
        src_nm,
        sum(actl_nsv) as actl_nsv,
        sum(yr_ago_actl_nsv) as yr_ago_actl_nsv,
        sum(actl_gsv) as actl_gsv,
        sum(yr_ago_actl_gsv) as yr_ago_actl_gsv,
        sum(actl_net_kg_val) as actl_net_kg_val,
        sum(yr_ago_actl_net_kg_val) as yr_ago_actl_net_kg_val,
        sum(actl_gross_prft_val) as actl_gross_prft_val,
        sum(yr_ago_actl_gross_prft_val) as yr_ago_actl_gross_prft_val,
        sum(actl_trade_val) as actl_trade_val,
        sum(yr_ago_trade_val) as yr_ago_trade_val
    from pl_export
    where ytd_ytg_cd = 'YTD' 
    and fisc_yr_qtr = (select max(fisc_yr_qtr) from pl_export where ytd_ytg_cd = 'YTD')
    group by 1,2,3,4,5,6,7
),

ytd_timeframe as (
    select 
        plan_to_nm,
        plan_to_nbr,
        'YTD' as tmfrm_cd,
        catg_nm,
        dp_bu_cd,
        comrcl_catg_cd,
        src_nm,
        sum(actl_nsv) as actl_nsv,
        sum(yr_ago_actl_nsv) as yr_ago_actl_nsv,
        sum(actl_gsv) as actl_gsv,
        sum(yr_ago_actl_gsv) as yr_ago_actl_gsv,
        sum(actl_net_kg_val) as actl_net_kg_val,
        sum(yr_ago_actl_net_kg_val) as yr_ago_actl_net_kg_val,
        sum(actl_gross_prft_val) as actl_gross_prft_val,
        sum(yr_ago_actl_gross_prft_val) as yr_ago_actl_gross_prft_val,
        sum(actl_trade_val) as actl_trade_val,
        sum(yr_ago_trade_val) as yr_ago_trade_val
    from pl_export
    where ytd_ytg_cd = 'YTD' 
    and fisc_yr = (select max(fisc_yr) from pl_export where ytd_ytg_cd = 'YTD')
    group by 1,2,3,4,5,6,7
)

select * from qtd_timeframe
union all
select * from ytd_timeframe
