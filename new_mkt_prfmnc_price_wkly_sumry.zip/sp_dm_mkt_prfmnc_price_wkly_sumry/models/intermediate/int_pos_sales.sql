with pos_sales_curr as (
    select 
        src_nm,
        left(fisc_yr_wk, 4) as fisc_yr,
        right(fisc_yr_wk, 3) as fisc_wk,
        retlr_nm,
        sold_to_nbr,
        gtin,
        gtin_type_cd,
        sum(sale_val) as sale_val,
        sum(sale_qty) as sale_qty,
        sum(sale_vol_lb_val) as sale_vol_lb_val
    from {{ source('sales_prfmnc_eval', 'mkt_prfmnc_pos_store_gtin') }}
    where fisc_dt between current_date - interval '59 week' and current_date
    group by 1,2,3,4,5,6,7
),

pos_sales_ly as (
    select 
        src_nm,
        left(fisc_yr_wk, 4) as fisc_yr,
        right(fisc_yr_wk, 3) as fisc_wk,
        retlr_nm,
        sold_to_nbr,
        gtin,
        gtin_type_cd,
        sum(sale_val) as yr_ago_sale_val,
        sum(sale_qty) as yr_ago_sale_qty,
        sum(sale_vol_lb_val) as yr_ago_sale_vol_lb_val
    from {{ source('sales_prfmnc_eval', 'mkt_prfmnc_pos_store_gtin') }}
    where fisc_dt between current_date - interval '115 week' and current_date - interval '52 week'
    group by 1,2,3,4,5,6,7
),

pos_sales_combined as (
    select
        coalesce(a.src_nm, b.src_nm) as src_nm,
        coalesce(a.fisc_yr, (b.fisc_yr::int+1)::text) as fisc_yr,
        coalesce(a.fisc_wk, b.fisc_wk) as fisc_wk,
        coalesce(a.retlr_nm, b.retlr_nm) as retlr_nm,
        coalesce(a.sold_to_nbr, b.sold_to_nbr) as sold_to_nbr,
        coalesce(a.gtin, b.gtin) as gtin,
        coalesce(a.gtin_type_cd, b.gtin_type_cd) as gtin_type_cd,
        a.sale_val,
        a.sale_qty,
        a.sale_vol_lb_val,
        b.yr_ago_sale_val,
        b.yr_ago_sale_qty,
        b.yr_ago_sale_vol_lb_val,
        case 
            when a.fisc_wk is null then 'LY' 
            when b.fisc_wk is null then 'CUR' 
            else 'BOTH' 
        end as avail
    from pos_sales_curr a
    full outer join pos_sales_ly b 
        on a.src_nm = b.src_nm 
        and a.retlr_nm = b.retlr_nm
        and a.sold_to_nbr = b.sold_to_nbr
        and a.gtin = b.gtin
        and a.fisc_yr::int - 1 = b.fisc_yr::int
        and a.fisc_wk = b.fisc_wk
)

select * from pos_sales_combined
