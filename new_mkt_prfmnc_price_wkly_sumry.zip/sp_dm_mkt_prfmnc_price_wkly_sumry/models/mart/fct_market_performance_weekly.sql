with pl_export_timeframes as (
    select * from {{ ref('int_pl_export_timeframes') }}
),

pos_final as (
    select * from {{ ref('int_pos_final') }}
),

fiscal_calendar as (
    select * from {{ source('fin_acctg_ops', 'ref_fisc_cal_wk') }}
),

pl_export_data as (
    select 
        'SALES_PERFORMANCE' as sectn_nm,
        'NA' as sold_to_nbr,
        'NA' as sold_to_nm,
        fcal.fisc_wk_end_dt,
        fcal.fisc_wk_end_dt as latst_data_avail_dt,
        plan_to_nm,
        plan_to_nbr,
        tmfrm_cd,
        catg_nm,
        dp_bu_cd,
        comrcl_catg_cd,
        src_nm,
        actl_nsv,
        yr_ago_actl_nsv,
        actl_gsv,
        yr_ago_actl_gsv,
        actl_net_kg_val,
        yr_ago_actl_net_kg_val,
        (actl_net_kg_val * 2.20462) as actl_net_lb_val,
        (yr_ago_actl_net_kg_val * 2.20462) as yr_ago_actl_net_lb_val,
        actl_gross_prft_val,
        yr_ago_actl_gross_prft_val,
        actl_trade_val,
        yr_ago_trade_val,
        0.0 as sale_val,
        0.0 as yr_ago_sale_val,
        0 as sale_qty,
        0 as yr_ago_sale_qty,
        0.0 as sale_vol_lb_val,
        0.0 as yr_ago_sale_vol_lb_val
    from pl_export_timeframes pl
    cross join (
        select max(fisc_wk_end_dt) as fisc_wk_end_dt
        from fiscal_calendar
        where fisc_yr_pd = (
            select max(fisc_yr_pd) 
            from {{ ref('int_pl_export') }}
            where ytd_ytg_cd = 'YTD'
        )
    ) fcal
    where upper(plan_to_nm) not like '%INACTIVE%'
),

pos_data as (
    select 
        'SALES_VALUE' as sectn_nm,
        sold_to_nbr,
        sold_to_nm,
        fisc_wk_end_dt,
        current_date as latst_data_avail_dt,
        plan_to_nm,
        plan_to_nbr,
        'NA' as tmfrm_cd,
        catg_nm,
        dp_bu_cd,
        comrcl_catg_cd,
        src_nm,
        0.0 as actl_nsv,
        0.0 as yr_ago_actl_nsv,
        0.0 as actl_gsv,
        0.0 as yr_ago_actl_gsv,
        0.0 as actl_net_kg_val,
        0.0 as yr_ago_actl_net_kg_val,
        0.0 as actl_net_lb_val,
        0.0 as yr_ago_actl_net_lb_val,
        0.0 as actl_gross_prft_val,
        0.0 as yr_ago_actl_gross_prft_val,
        0.0 as actl_trade_val,
        0.0 as yr_ago_trade_val,
        coalesce(sale_val, 0) as sale_val,
        coalesce(yr_ago_sale_val, 0) as yr_ago_sale_val,
        coalesce(sale_qty, 0) as sale_qty,
        coalesce(yr_ago_sale_qty, 0) as yr_ago_sale_qty,
        coalesce(sale_vol_lb_val, 0) as sale_vol_lb_val,
        coalesce(yr_ago_sale_vol_lb_val, 0) as yr_ago_sale_vol_lb_val
    from pos_final
    where upper(plan_to_nm) not like '%INACTIVE%'
    and upper(sold_to_nm) not like '%INACTIVE%'
),

final as (
    select
        sectn_nm,
        tmfrm_cd,
        fisc_wk_end_dt,
        latst_data_avail_dt,
        sold_to_nm,
        sold_to_nbr,
        coalesce(plan_to_nm, '') as plan_to_nm,
        plan_to_nbr,
        coalesce(catg_nm, 'NA') as catg_nm,
        coalesce(dp_bu_cd, 'NA') as dp_bu_cd,
        coalesce(comrcl_catg_cd, 'NA') as comrcl_catg_cd,
        actl_nsv,
        yr_ago_actl_nsv,
        actl_gsv,
        yr_ago_actl_gsv,
        actl_net_kg_val,
        yr_ago_actl_net_kg_val,
        actl_net_lb_val,
        yr_ago_actl_net_lb_val,
        actl_gross_prft_val,
        yr_ago_actl_gross_prft_val,
        actl_trade_val,
        yr_ago_trade_val,
        sale_val,
        yr_ago_sale_val,
        sale_qty,
        yr_ago_sale_qty,
        sale_vol_lb_val,
        yr_ago_sale_vol_lb_val,
        src_nm,
        md5(
            src_nm || sectn_nm || fisc_wk_end_dt || tmfrm_cd || 
            plan_to_nbr || plan_to_nm || catg_nm || dp_bu_cd || comrcl_catg_cd
        ) as hash_key,
        current_timestamp as kortex_dprct_ts,
        current_timestamp as kortex_upld_ts,
        current_timestamp as kortex_cre_ts,
        current_timestamp as kortex_updt_ts
    from (
        select * from pl_export_data
        union all
        select * from pos_data
    )
    where plan_to_nbr is not null
)

select * from final
