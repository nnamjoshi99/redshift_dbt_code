with source as (
    select * from {{ source('sales_prfmnc_eval', 'sales_rptg_sales_trkr') }}
),

staged as (
    select
        lpad(plan_to_nbr, 10, '0') as plan_to_nbr,
        fisc_yr,
        fisc_qtr,
        fisc_pd,
        (fisc_yr::varchar || lpad(fisc_qtr::varchar, 3, '0'))::int as fisc_yr_qtr,
        (fisc_yr::varchar || lpad(fisc_pd::varchar, 3, '0'))::int as fisc_yr_pd,
        catg_nm,
        dp_bu_cd,
        val_curr_cd,
        case
            when catg_nm in ('COLD CEREAL','CEREAL','CEREAL ALTERNATIVES','HOT CEREAL','OTHER CONVENIENCE','RTEC') 
                and (dp_bu_cd = 'K1') then 'CEREAL'
            when catg_nm in ('COOKIES','INGREDIENTS') 
                and (dp_bu_cd = 'K1') then 'COOKIES & OTHER'
            when catg_nm in ('HANDHELD','SYRUP CARRIERS','FROZEN BREAKFAST') 
                and (dp_bu_cd = 'K1') then 'FROZEN BREAKFAST'
            when catg_nm in ('BARS','CEREAL ALTERNATIVES','COLD CEREAL','CEREAL','COOKIES','CRACKERS','DRINKABLE BREAKFAST',
                'FROZEN MEALS','FRUIT SNACKS','H&W BEVERAGES','HANDHELD','HOT CEREAL','INGREDIENTS','MEAT SNACK ALTERNATIVES',
                'FROZEN BREAKFAST','OTHER CONVENIENCE','PLANT PROTEIN ADJACENCY','SALTY SNACKS','SYRUP CARRIERS','TOASTER PASTRIES','VEGGIE')
                and ((dp_bu_cd = 'N&I') or (dp_bu_cd = 'KASHI') or (dp_bu_cd = 'INSURGENT BRANDS')) then 'NATURAL & INSURGENT'
            when catg_nm in ('BARS','DRINKABLE BREAKFAST','FRUIT SNACKS','H&W BEVERAGES','TOASTER PASTRIES','BEVERAGES') 
                and (dp_bu_cd = 'K1') then 'PWS'
            when catg_nm in ('CRACKERS','SALTY SNACKS') 
                and (dp_bu_cd = 'K1') then 'SALTY SNACKING'
            when catg_nm in ('FROZEN MEALS','PLANT PROTEIN ADJACENCY','VEGGIE') 
                and (dp_bu_cd = 'K1') then 'VEGGIE'
        end as comrcl_catg_cd,
        ytd_ytg_cd,
        meas_nm,
        src_nm,
        actl_meas_val::float as actl_meas_val,
        actl_yr_ago_meas_val::float as actl_yr_ago_meas_val
    from source
    where dp_bu_cd in ('K1', 'KASHI', 'N&I', 'INSURGENT BRANDS')
)

select * from staged
