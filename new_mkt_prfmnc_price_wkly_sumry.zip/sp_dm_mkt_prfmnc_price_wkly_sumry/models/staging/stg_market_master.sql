with source as (
    select * from {{ source('raw', 'market_master') }}
),

renamed as (
    select
        market_id,
        market_name,
        market_region,
        market_type,
        is_active,
        created_at,
        updated_at
    from source
)

select * from renamed
